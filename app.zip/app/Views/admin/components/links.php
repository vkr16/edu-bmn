<link rel="shortcut icon" href="<?= IMAGES_URL ?>/logo.png" type="image/x-icon">

<!-- Bootstrap CSS-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css">

<!-- Datatables CSS -->
<link rel="stylesheet" href="<?= ASSETS_URL ?>/js/datatables/datatables.min.css">

<!-- Custom CSS -->
<link rel="stylesheet" href="<?= ASSETS_URL ?>/css/main.css" />