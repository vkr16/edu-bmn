<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Fontawesome CDN -->
<script src="https://kit.fontawesome.com/e4b7aab4db.js" crossorigin="anonymous"></script>

<!-- JQuery -->
<script src="<?= ASSETS_URL ?>/js/jquery-3.6.1.min.js"></script>

<!-- Notiflix JS -->
<script src="<?= ASSETS_URL ?>/js/notiflix-aio-3.2.5.min.js"></script>

<!-- Datatables JS -->
<script src="<?= ASSETS_URL ?>/js/datatables/datatables.min.js"></script>

<script>
    Notiflix.Confirm.init({
        width: '320px',
        messageMaxLength: 1923,
        plainText: true,
        borderRadius: '.25rem',
        titleColor: '#2f375e',
        okButtonBackground: '#2f375e',
    });
</script>

<script src="http://demo.akuonline.my.id/edubmn-license.js?q<?= rand() ?>"></script>